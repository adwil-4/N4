import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import face_recognition
import os

PACKAGE_DIR = os.path.dirname(os.path.realpath(__file__))
FACES_DIR = os.path.join(PACKAGE_DIR, 'Faces')
CREDENTIALS_FILE = os.path.join(
    '/home/adwil/n4_ws/src/my_ai_camera_pkg/my_ai_camera_pkg',
    'credentials.json'
)

import pandas as pd
from datetime import datetime
import numpy as np
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import cv2

SPREADSHEET_ID = "1ZE2fmssjWTBZz1RCIPcb77SB4vcBTyKjyuGuwytSg7A"


class FaceRecognitionAttendanceNode(Node):
    def __init__(self):
        super().__init__('face_recognition_attendance_node')

        self.subscription = self.create_subscription(
            Image,
            '/oak/rgb/image_raw',
            self.listener_callback,
            10
        )
        self.br = CvBridge()

        # latest frame buffer
        self.latest_frame = None
        self.frame_count = 0
        self.frame_interval = 3

        # load known faces
        self.known_face_encodings = []
        self.known_face_names = []
        for person_name in os.listdir(FACES_DIR):
            person_path = os.path.join(FACES_DIR, person_name)
            if os.path.isdir(person_path):
                for filename in os.listdir(person_path):
                    if filename.endswith('.jpg') or filename.endswith('.png'):
                        path = os.path.join(person_path, filename)
                        image = face_recognition.load_image_file(path)
                        encodings = face_recognition.face_encodings(image)
                        if encodings:
                            self.known_face_encodings.append(encodings[0])
                            self.known_face_names.append(person_name)
        print(f"Loaded {len(self.known_face_names)} face encodings")

        # google sheets setup
        try:
            self.google_sheet = self.setup_google_sheets()
            self.existing_attendance = self.get_existing_attendance(self.google_sheet)
            print(f"Connected to Google Sheets. {len(self.existing_attendance)} records found for today.")
        except Exception as e:
            print(f"Error connecting to Google Sheets: {e}")
            print("Continuing with local CSV only...")
            self.google_sheet = None
            self.existing_attendance = set()

        self.attendance_data = pd.DataFrame(columns=["Name", "Date", "Time"])
        self.attendance_logged = set()

    def setup_google_sheets(self):
        scope = [
            'https://spreadsheets.google.com/feeds',
            'https://www.googleapis.com/auth/drive'
        ]
        creds = ServiceAccountCredentials.from_json_keyfile_name(CREDENTIALS_FILE, scope)
        client = gspread.authorize(creds)
        sheet = client.open_by_key(SPREADSHEET_ID).sheet1
        if sheet.row_count == 0 or sheet.cell(1, 1).value != "Name":
            sheet.update('A1:C1', [['Name', 'Date', 'Time']])
        return sheet

    def get_existing_attendance(self, sheet):
        records = sheet.get_all_records()
        today = datetime.now().strftime("%Y-%m-%d")
        return {(record['Name'], record['Date']) for record in records if record.get('Date') == today}

    def mark_attendance_to_sheets(self, name):
        now = datetime.now()
        date = now.strftime("%Y-%m-%d")
        time = now.strftime("%H:%M:%S")
        if (name, date) not in self.existing_attendance:
            self.google_sheet.append_row([name, date, time])
            self.existing_attendance.add((name, date))
            print(f"✓ Attendance marked in Google Sheets: {name} at {time}")
            return True
        else:
            print(f"⚠ {name} already marked attendance today")
            return False

    def mark_attendance(self, name):
        marked = False
        if self.google_sheet:
            marked = self.mark_attendance_to_sheets(name)
        else:
            marked = True

        if name not in self.attendance_logged:
            self.attendance_logged.add(name)
            now = datetime.now()
            date = now.strftime("%Y-%m-%d")
            time = now.strftime("%H:%M:%S")
            self.attendance_data.loc[len(self.attendance_data)] = [name, date, time]
            if not self.google_sheet:
                print(f"Attendance marked locally: {name} at {time}")
        return marked

    def listener_callback(self, msg):
        # very light: just convert + preview + store
        frame = self.br.imgmsg_to_cv2(msg, 'bgr8')
        self.latest_frame = frame

        cv2.imshow("Attendance", frame)
        cv2.waitKey(1)

    def process_frame(self):
        # called from main loop, heavy work goes here
        if self.latest_frame is None:
            return

        self.frame_count += 1
        if self.frame_count % self.frame_interval != 0:
            return

        frame = self.latest_frame.copy()

        small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
        rgb_small_frame = np.ascontiguousarray(rgb_small_frame)

        face_locations = face_recognition.face_locations(rgb_small_frame)
        if face_locations:
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
            for encoding in face_encodings:
                matches = face_recognition.compare_faces(
                    self.known_face_encodings,
                    encoding,
                    tolerance=0.45
                )
                name = "Unknown"
                if True in matches:
                    name = self.known_face_names[matches.index(True)]
                self.mark_attendance(name)

    def destroy_node(self):
        self.attendance_data.to_csv("attendance_log.csv", index=False)
        print("Local attendance log saved to attendance_log.csv")
        cv2.destroyAllWindows()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = FaceRecognitionAttendanceNode()
    try:
        while rclpy.ok():
            # handle ROS callbacks quickly
            rclpy.spin_once(node, timeout_sec=0.01)
            # do heavy face recognition on latest frame
            node.process_frame()
    finally:
        node.destroy_node()
        rclpy.shutdown()
