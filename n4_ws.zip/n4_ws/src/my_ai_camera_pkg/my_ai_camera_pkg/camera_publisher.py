import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import depthai as dai
import cv2

def main(args=None):
    rclpy.init(args=args)
    node = DepthAICameraPublisher()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

class DepthAICameraPublisher(Node):
    def __init__(self):
        super().__init__('depthai_camera_publisher')
        self.publisher_ = self.create_publisher(Image, '/oak/rgb/image_raw', 10)
        self.br = CvBridge()
        self.pipeline = dai.Pipeline()
        cam_rgb = self.pipeline.createColorCamera()
        cam_rgb.setPreviewSize(640, 480)
        cam_rgb.setInterleaved(False)
        xout = self.pipeline.createXLinkOut()
        xout.setStreamName('rgb')
        cam_rgb.preview.link(xout.input)
        self.device = dai.Device(self.pipeline)
        self.q_rgb = self.device.getOutputQueue(name='rgb', maxSize=4, blocking=False)
        self.timer = self.create_timer(0.1, self.publish_frame)  # 10 fps
    def publish_frame(self):
        in_rgb = self.q_rgb.get()
        if in_rgb is not None:
            frame = in_rgb.getCvFrame()
            img_msg = self.br.cv2_to_imgmsg(frame, 'bgr8')
            self.publisher_.publish(img_msg)
    def destroy_node(self):
        self.device.close()
        super().destroy_node()
