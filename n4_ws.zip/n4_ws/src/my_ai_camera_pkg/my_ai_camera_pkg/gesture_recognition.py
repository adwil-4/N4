import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Image
from cv_bridge import CvBridge

import cv2
import mediapipe as mp
from collections import deque


class GestureRecognitionNode(Node):
    def __init__(self):
        super().__init__('gesture_recognition_node')

        # Subscribe to camera images from your DepthAICameraPublisher
        self.subscription = self.create_subscription(
            Image,
            '/oak/rgb/image_raw',   # must match camera_publisher.py
            self.image_callback,
            10
        )

        self.bridge = CvBridge()

        # MediaPipe Hands setup
        self.mp_hands = mp.solutions.hands
        self.mp_draw = mp.solutions.drawing_utils
        self.hands = self.mp_hands.Hands(max_num_hands=1)

        # Wave detection setup (copied from your script)
        self.WAVE_BUF_LEN = 18
        self.WAVE_MIN_CHANGES = 1
        self.WAVE_MIN_MOVEMENT = 0.08
        self.wave_buffer = deque(maxlen=self.WAVE_BUF_LEN)
        self.wave_cooldown_frames = 30
        self.wave_cooldown_counter = 0

        self.get_logger().info('GestureRecognitionNode started, listening to /oak/rgb/image_raw')

    # ---------- your recognize_gesture logic, unchanged ----------
    def recognize_gesture(self, hand_landmarks):
        lm = hand_landmarks.landmark

        index_delta  = lm[self.mp_hands.HandLandmark.INDEX_FINGER_TIP].y  - lm[self.mp_hands.HandLandmark.INDEX_FINGER_PIP].y
        middle_delta = lm[self.mp_hands.HandLandmark.MIDDLE_FINGER_TIP].y - lm[self.mp_hands.HandLandmark.MIDDLE_FINGER_PIP].y
        ring_delta   = lm[self.mp_hands.HandLandmark.RING_FINGER_TIP].y   - lm[self.mp_hands.HandLandmark.RING_FINGER_PIP].y
        pinky_delta  = lm[self.mp_hands.HandLandmark.PINKY_TIP].y         - lm[self.mp_hands.HandLandmark.PINKY_PIP].y
        thumb_delta  = lm[self.mp_hands.HandLandmark.THUMB_TIP].x         - lm[self.mp_hands.HandLandmark.THUMB_IP].x

        thumb_tip = lm[self.mp_hands.HandLandmark.THUMB_TIP]
        index_tip = lm[self.mp_hands.HandLandmark.INDEX_FINGER_TIP]
        ok_dist = ((thumb_tip.x - index_tip.x)**2 + (thumb_tip.y - index_tip.y)**2)**0.5

        # Open Palm
        if (index_delta  < -0.07 and
            middle_delta < -0.07 and
            ring_delta   < -0.07 and
            pinky_delta  < -0.07):
            return "Open Palm"

        # Thumbs Up
        if (index_delta  > 0.005 and
            middle_delta > 0.005 and
            ring_delta   > 0.005 and
            pinky_delta  > 0.005 and
            thumb_delta  < 0.02):
            return "Thumbs Up"

        # OK Sign
        if ok_dist < 0.16 and middle_delta < -0.06:
            return "OK Sign"

        # Point Forward
        if ok_dist > 0.18 and middle_delta > 0.0:
            return "Point Forward"

        return "Unknown"
    # ------------------------------------------------------------

    def image_callback(self, msg: Image):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'cv_bridge error: {e}')
            return

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb)

        gesture = "None"
        wave_gesture = None

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                self.mp_draw.draw_landmarks(
                    frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS
                )
                gesture = self.recognize_gesture(hand_landmarks)

                # Wave detection (same logic as your script)
                idx = self.mp_hands.HandLandmark.WRIST
                x_norm = hand_landmarks.landmark[idx].x
                self.wave_buffer.append(x_norm)

                if (len(self.wave_buffer) == self.WAVE_BUF_LEN and
                    self.wave_cooldown_counter == 0):

                    total_movement = abs(self.wave_buffer[-1] - self.wave_buffer[0])
                    if total_movement > self.WAVE_MIN_MOVEMENT:
                        directions = []
                        for i in range(1, self.WAVE_BUF_LEN):
                            diff = self.wave_buffer[i] - self.wave_buffer[i-1]
                            if abs(diff) > 0.005:
                                directions.append(1 if diff > 0 else -1)

                        num_changes = 0
                        for i in range(1, len(directions)):
                            if directions[i] != directions[i-1]:
                                num_changes += 1

                        if num_changes >= self.WAVE_MIN_CHANGES:
                            wave_gesture = "Wave"
                            self.wave_cooldown_counter = self.wave_cooldown_frames

        if self.wave_cooldown_counter > 0:
            self.wave_cooldown_counter -= 1

        if wave_gesture:
            displayed_gesture = wave_gesture
        else:
            displayed_gesture = gesture

        # For now: just show window and log gesture
        cv2.putText(frame, f"Gesture: {displayed_gesture}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
        cv2.imshow("Gesture Recognition (ROS2)", frame)
        cv2.waitKey(1)

        self.get_logger().info(f"Gesture: {displayed_gesture}")

def main(args=None):
    rclpy.init(args=args)
    node = GestureRecognitionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
